var searchData=
[
  ['_5fcourse_17',['_course',['../struct__course.html',1,'']]],
  ['_5fstudent_18',['_student',['../struct__student.html',1,'']]]
];
